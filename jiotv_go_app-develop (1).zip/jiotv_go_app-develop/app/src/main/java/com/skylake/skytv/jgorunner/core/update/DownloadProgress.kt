package com.skylake.skytv.jgorunner.core.update

data class DownloadProgress(
    val fileName: String,
    val progress: Int,
)
